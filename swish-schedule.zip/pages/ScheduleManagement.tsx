
import React, { useState, useEffect } from 'react';
import { 
  X, ChevronLeft, ChevronRight, Clock, Plus, Search, Check, Calendar as CalendarIcon, Moon, AlertCircle, LogOut, Timer, Coffee, ChevronDown, ChevronUp
} from 'lucide-react';
import { useAuth } from '../App';
import { store } from '../store';
import { DayType, User, UserRole, ScheduleDay, Break } from '../types';
import { addDays, format } from 'date-fns';

const manualParseISO = (dateStr: string) => {
  const [y, m, d] = dateStr.split('-').map(Number);
  return new Date(y, m - 1, d);
};

const manualStartOfWeek = (date: Date) => {
  const d = new Date(date);
  const day = d.getDay();
  const diff = d.getDate() - day;
  const start = new Date(d.setDate(diff));
  start.setHours(0, 0, 0, 0);
  return start;
};

export default function ScheduleManagement() {
  const { user: currentUser } = useAuth();
  const [employees, setEmployees] = useState<User[]>([]);
  const [currentWeekStart, setCurrentWeekStart] = useState(manualStartOfWeek(new Date()));
  const [searchQuery, setSearchQuery] = useState('');
  const [allSchedules, setAllSchedules] = useState<Record<string, Record<string, ScheduleDay>>>({});
  const [collapsed, setCollapsed] = useState<Record<string, boolean>>({});
  
  const [editingDay, setEditingDay] = useState<{ userId: string, date: string } | null>(null);
  const [editFormData, setEditFormData] = useState<ScheduleDay | null>(null);

  useEffect(() => {
    const refreshData = async () => {
      const allUsers = await store.getUsers();
      let empList = allUsers.filter(u => u.role === UserRole.EMPLOYEE);
      if (currentUser?.role === UserRole.MANAGER) {
        empList = empList.filter(u => u.companyName === currentUser.companyName);
      }
      setEmployees(empList);
      const appData = await store.getCurrentAppData();
      setAllSchedules(appData.schedules);
    };
    refreshData();
  }, [currentUser, editingDay]);

  const weekDays = Array.from({ length: 7 }, (_, i) => addDays(currentWeekStart, i));

  const toggleCollapse = (id: string) => {
    setCollapsed(prev => ({ ...prev, [id]: !prev[id] }));
  };

  const handleEditDay = (userId: string, date: string, existing?: ScheduleDay) => {
    setEditingDay({ userId, date });
    setEditFormData(existing || {
      id: Math.random().toString(),
      date,
      type: DayType.NORMAL_SHIFT,
      shift: {
        startTime: '08:00',
        endTime: '16:00',
        breaks: [
          { id: '1', start: '10:00', end: '10:15' },
          { id: '2', start: '13:00', end: '13:30' },
          { id: '3', start: '15:30', end: '15:45' }
        ] as [Break, Break, Break]
      }
    });
  };

  const saveDay = async () => {
    if (editingDay && editFormData) {
      await store.updateDay(editingDay.userId, editingDay.date, editFormData);
      setEditingDay(null);
      setEditFormData(null);
    }
  };

  const filteredEmployees = employees.filter(e => 
    e.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
    e.employeeId?.toLowerCase().includes(searchQuery.toLowerCase())
  );

  return (
    <div className="space-y-10 max-w-7xl mx-auto pb-20 animate-in fade-in slide-in-from-bottom-4 duration-700">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-8">
        <div>
          <h1 className="text-5xl font-black text-gray-900 tracking-tighter">Team Roster</h1>
          <p className="text-gray-400 font-medium mt-2 text-lg">Synchronized weekly scheduling for your entire workforce.</p>
        </div>
        <div className="flex items-center bg-white border border-gray-100 rounded-[28px] p-2 shadow-xl shadow-blue-50/50">
          <button onClick={() => setCurrentWeekStart(addDays(currentWeekStart, -7))} className="p-3.5 hover:bg-blue-50 hover:text-blue-600 rounded-[20px] text-gray-400 transition-all duration-300 active:scale-90"><ChevronLeft size={24} /></button>
          <div className="px-10 text-base font-black text-gray-800 tracking-tight">
            {format(currentWeekStart, 'MMMM d')} - {format(addDays(currentWeekStart, 6), 'd')}
          </div>
          <button onClick={() => setCurrentWeekStart(addDays(currentWeekStart, 7))} className="p-3.5 hover:bg-blue-50 hover:text-blue-600 rounded-[20px] text-gray-400 transition-all duration-300 active:scale-90"><ChevronRight size={24} /></button>
        </div>
      </div>

      <div className="relative max-w-xl group">
        <Search className="absolute left-6 top-1/2 -translate-y-1/2 text-gray-300 group-focus-within:text-blue-500 transition-colors" size={24} />
        <input 
          type="text" 
          placeholder="Filter team by name or ID..." 
          value={searchQuery}
          onChange={(e) => setSearchQuery(e.target.value)}
          className="w-full pl-16 pr-8 py-6 rounded-[32px] border-2 border-gray-50 text-base focus:ring-4 focus:ring-blue-100 focus:border-blue-500 bg-white shadow-xl shadow-blue-50/10 outline-none transition-all placeholder:text-gray-300 placeholder:font-medium"
        />
      </div>

      <div className="space-y-8">
        {filteredEmployees.map(emp => (
          <div key={emp.id} className="bg-white rounded-[48px] border border-gray-100 shadow-2xl shadow-blue-50/10 overflow-hidden transition-all duration-500 hover:shadow-blue-100/30">
            <div 
              onClick={() => toggleCollapse(emp.id)}
              className="px-10 py-8 flex items-center justify-between cursor-pointer hover:bg-gray-50/50 transition-colors"
            >
              <div className="flex items-center space-x-8">
                <div className="relative">
                  <div className="w-16 h-16 rounded-[24px] bg-gray-900 flex items-center justify-center font-black text-white text-2xl shadow-xl shadow-gray-200">
                    {emp.name.charAt(0)}
                  </div>
                  <div className="absolute -bottom-1 -right-1 w-6 h-6 bg-emerald-500 border-4 border-white rounded-full"></div>
                </div>
                <div>
                  <h3 className="text-2xl font-black text-gray-900 tracking-tighter leading-none mb-1">{emp.name}</h3>
                  <div className="flex items-center space-x-3">
                    <span className="text-[10px] font-black text-blue-600 uppercase tracking-[0.2em]">{emp.jobTitle || 'Team Member'}</span>
                    <span className="w-1 h-1 bg-gray-200 rounded-full"></span>
                    <span className="text-[10px] font-black text-gray-300 uppercase tracking-widest">ID: {emp.employeeId || 'N/A'}</span>
                  </div>
                </div>
              </div>
              <div className="flex items-center space-x-6">
                <div className="hidden lg:flex items-center space-x-1 opacity-40 hover:opacity-100 transition-opacity">
                   <Clock size={16} className="text-gray-400" />
                   <span className="text-[10px] font-black uppercase tracking-widest text-gray-400">Weekly View</span>
                </div>
                <div className={`p-4 rounded-2xl transition-all duration-500 ${collapsed[emp.id] ? 'bg-gray-50 text-gray-300' : 'bg-blue-50 text-blue-600'}`}>
                  {collapsed[emp.id] ? <ChevronDown size={20} /> : <ChevronUp size={20} />}
                </div>
              </div>
            </div>

            {!collapsed[emp.id] && (
              <div className="px-10 pb-10 pt-4 grid grid-cols-1 md:grid-cols-2 lg:grid-cols-7 gap-4 border-t border-gray-50 animate-in zoom-in-95 fade-in duration-500">
                {weekDays.map(day => {
                  const dateStr = format(day, 'yyyy-MM-dd');
                  const data = (allSchedules[emp.id] || {})[dateStr];
                  const isNormal = data?.type === DayType.NORMAL_SHIFT;

                  return (
                    <div 
                      key={dateStr}
                      onClick={() => handleEditDay(emp.id, dateStr, data)}
                      className={`group p-6 rounded-[32px] border-2 transition-all duration-300 cursor-pointer flex flex-col justify-between min-h-[190px] relative overflow-hidden ${
                        isNormal 
                          ? 'bg-blue-50/40 border-blue-100 hover:bg-blue-50 hover:border-blue-400 hover:shadow-xl hover:shadow-blue-100/50' 
                          : 'bg-gray-50/50 border-gray-100 hover:bg-gray-50 hover:border-gray-300'
                      }`}
                    >
                      <div className="relative z-10">
                        <p className="text-[10px] font-black text-gray-400 uppercase tracking-widest mb-1">{format(day, 'EEEE')}</p>
                        <p className={`text-2xl font-black ${isNormal ? 'text-blue-600' : 'text-gray-900'}`}>{format(day, 'd')}</p>
                      </div>

                      <div className="mt-6 relative z-10">
                        {data ? (
                          <div className="space-y-3">
                            <span className={`text-[9px] font-black uppercase px-2.5 py-1 rounded-lg tracking-widest inline-block ${
                              isNormal ? 'bg-blue-600 text-white shadow-lg shadow-blue-200' : 'bg-white text-gray-400 border border-gray-100'
                            }`}>
                              {data.type.replace('_', ' ')}
                            </span>
                            {isNormal && data.shift && (
                              <div className="text-[11px] font-black text-gray-700 flex items-center space-x-2">
                                <Clock size={12} className="text-blue-500" />
                                <span>{data.shift.startTime} - {data.shift.endTime}</span>
                              </div>
                            )}
                          </div>
                        ) : (
                          <div className="flex items-center space-x-2 text-gray-300 group-hover:text-blue-400 transition-colors">
                            <Plus size={18} />
                            <span className="text-[10px] font-black uppercase tracking-widest">Assign</span>
                          </div>
                        )}
                      </div>
                      
                      {isNormal && (
                         <div className="absolute -bottom-6 -right-6 text-blue-500 opacity-[0.03] group-hover:opacity-10 transition-opacity">
                            <CalendarIcon size={120} />
                         </div>
                      )}
                    </div>
                  );
                })}
              </div>
            )}
          </div>
        ))}
        {filteredEmployees.length === 0 && (
          <div className="py-20 text-center">
            <Search size={48} className="mx-auto text-gray-100 mb-4" />
            <p className="text-gray-400 font-bold">No matching employees found for "{searchQuery}"</p>
          </div>
        )}
      </div>

      {editingDay && editFormData && (
        <div className="fixed inset-0 z-[100] flex items-center justify-center p-4 bg-gray-900/80 backdrop-blur-md">
          <div className="bg-white rounded-[56px] shadow-2xl w-full max-w-xl overflow-hidden animate-in zoom-in-95 duration-300">
            <div className="px-12 py-10 border-b border-gray-50 flex justify-between items-center bg-[#F8FAFC]">
              <div>
                <h2 className="text-3xl font-black text-gray-900 tracking-tighter">Day Roster</h2>
                <p className="text-xs font-black text-blue-600 uppercase tracking-[0.2em] mt-2">{format(manualParseISO(editingDay.date), 'EEEE, MMMM do, yyyy')}</p>
              </div>
              <button onClick={() => setEditingDay(null)} className="p-4 bg-white rounded-[24px] text-gray-300 hover:text-gray-900 hover:rotate-90 shadow-sm transition-all duration-500"><X size={28} /></button>
            </div>
            
            <div className="p-12 space-y-10 overflow-y-auto max-h-[70vh]">
              <div>
                <label className="text-[11px] font-black text-gray-300 uppercase tracking-[0.2em] mb-6 block">Shift Category</label>
                <div className="grid grid-cols-3 gap-3">
                  {Object.values(DayType).filter(t => t !== 'TARDY' && t !== 'EARLY_LEAVE').map(type => (
                    <button
                      key={type}
                      onClick={() => setEditFormData({ ...editFormData, type })}
                      className={`py-4 px-3 rounded-[24px] text-[10px] font-black uppercase border-2 transition-all duration-300 ${
                        editFormData.type === type 
                        ? 'border-blue-600 bg-blue-600 text-white shadow-xl shadow-blue-200 scale-105' 
                        : 'border-gray-50 bg-gray-50 text-gray-400 hover:border-gray-200'
                      }`}
                    >
                      {type.replace('_', ' ')}
                    </button>
                  ))}
                </div>
              </div>

              {editFormData.type === DayType.NORMAL_SHIFT && editFormData.shift && (
                <div className="space-y-10 animate-in slide-in-from-top-4 duration-500">
                  <div className="grid grid-cols-2 gap-8">
                    <div className="space-y-3">
                      <label className="text-[11px] font-black text-gray-300 uppercase tracking-widest ml-2">Clock In</label>
                      <input type="time" value={editFormData.shift.startTime} onChange={(e) => setEditFormData({...editFormData, shift: {...editFormData.shift!, startTime: e.target.value}})} className="w-full px-8 py-5 text-xl font-black text-gray-800 bg-gray-50 border-2 border-transparent rounded-[24px] outline-none focus:border-blue-500 focus:bg-white transition-all shadow-sm" />
                    </div>
                    <div className="space-y-3">
                      <label className="text-[11px] font-black text-gray-300 uppercase tracking-widest ml-2">Clock Out</label>
                      <input type="time" value={editFormData.shift.endTime} onChange={(e) => setEditFormData({...editFormData, shift: {...editFormData.shift!, endTime: e.target.value}})} className="w-full px-8 py-5 text-xl font-black text-gray-800 bg-gray-50 border-2 border-transparent rounded-[24px] outline-none focus:border-blue-500 focus:bg-white transition-all shadow-sm" />
                    </div>
                  </div>

                  <div className="space-y-6">
                    <div className="flex items-center justify-between px-2">
                      <label className="text-[11px] font-black text-gray-300 uppercase tracking-widest">Mandatory Breaks (3)</label>
                      <div className="flex items-center space-x-2">
                        <Coffee size={14} className="text-orange-500" />
                        <span className="text-[9px] font-black text-orange-600 uppercase">Fixed Protocol</span>
                      </div>
                    </div>
                    <div className="space-y-4">
                      {editFormData.shift.breaks.map((br, idx) => (
                        <div key={idx} className="flex items-center space-x-6 bg-gray-50 p-6 rounded-[32px] border border-gray-100 transition-all hover:bg-white hover:shadow-lg">
                          <div className="w-14 h-14 rounded-[20px] bg-white flex flex-col items-center justify-center border border-gray-100 shadow-sm">
                            <span className="text-[10px] font-black text-gray-400">#0{idx+1}</span>
                          </div>
                          <div className="flex-1 grid grid-cols-2 gap-4">
                            <div className="space-y-1">
                               <span className="text-[8px] font-black text-gray-400 uppercase ml-1">Start</span>
                               <input type="time" value={br.start} onChange={(e) => { const nb = [...editFormData.shift!.breaks]; nb[idx].start = e.target.value; setEditFormData({...editFormData, shift: {...editFormData.shift!, breaks: nb as any}})}} className="w-full bg-white p-3 text-sm font-black border border-gray-100 rounded-xl outline-none focus:ring-2 focus:ring-orange-400 transition-all" />
                            </div>
                            <div className="space-y-1">
                               <span className="text-[8px] font-black text-gray-400 uppercase ml-1">End</span>
                               <input type="time" value={br.end} onChange={(e) => { const nb = [...editFormData.shift!.breaks]; nb[idx].end = e.target.value; setEditFormData({...editFormData, shift: {...editFormData.shift!, breaks: nb as any}})}} className="w-full bg-white p-3 text-sm font-black border border-gray-100 rounded-xl outline-none focus:ring-2 focus:ring-orange-400 transition-all" />
                            </div>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                </div>
              )}

              <div className="flex flex-col space-y-4 pt-10 border-t border-gray-50">
                <button onClick={saveDay} className="w-full py-6 bg-gray-900 text-white rounded-[32px] text-lg font-black shadow-2xl shadow-gray-200 hover:bg-black transition-all active:scale-95 flex items-center justify-center space-x-4 group">
                  <Check size={28} className="group-hover:scale-125 transition-transform" />
                  <span>Update Roster</span>
                </button>
                <button onClick={() => setEditingDay(null)} className="w-full py-2 text-xs font-black text-gray-300 hover:text-gray-500 uppercase tracking-widest">Discard Changes</button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
